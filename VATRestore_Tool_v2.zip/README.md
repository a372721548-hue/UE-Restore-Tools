# VAT → Houdini 动画还原工具

双击 **Launch.vbs** 启动，无需提前打开 Houdini，也无需安装 Python 包。

1. 选择还原类型，再选择 UE 导出的原始 FBX 网格。
2. 动态重网格模式选择 Lookup 和 Position；粒子面片模式选择 Rotation 和 Position。同目录只有一套对应文件时会自动填入。
3. 选择输出父目录，设置播放帧率，点击「开始还原」。
4. 完成后点击「打开 Houdini 工程」，播放时间轴。

每次生成独立的结果目录，不覆盖已有结果。移动生成的工程时，请将旁边的 `cache` 文件夹一起移动。工具本身也可以整文件夹移动。

## 支持范围

- Windows，已安装且可正常授权的 Houdini；已用 Houdini 21.0.440 验证。
- 与本次提供的 `MF_DynamicRemeshing` 编码一致的 Dynamic Remeshing VAT。
- UE 导出的三角形 FBX，保留 UV0 和嵌入参数的原始包围盒；不要在导出后缩放或重建网格。
- 单张 HDR Position（EXR/HDR），四通道 Lookup（PNG/EXR 等），支持该函数的 255 / 2048 查找表分支。
- 本版本不支持骨骼、刚体碎块 VAT、其他自定义编码、双位置贴图、LDR 位置。动态重网格模式暂不支持仅靠材质实例提供的 Legacy 包围盒参数。尺寸与参数检查可以发现部分错误，但不能证明任意两个同尺寸文件一定配套。

恢复真实逐帧几何体，不依赖 UE 材质。法线重新计算，因此无需 Rotation / Color / 水面法线贴图。未重建原水材质、额外 WPO 变形或粒子运动。默认 60 FPS 可修改，不会自动读取 UE 材质实例的速度覆盖值。

解码时保留 Lookup 原始 RGBA 数值，不进行颜色空间变换或 Alpha 预乘。坐标转换为 Houdini Y 向上、米。删除辅助调试三角形和退化面，按位置纹理索引合并共享点。动态拓扑不能直接按点编号插值。

生成后重新打开工程并逐帧计算验证；验证记录在 `validation.json`。失败或中断的目录保留 `INCOMPLETE.txt`，不应当作成功结果。

## 新增：本次 ParticleSprites 粒子面片模式

适用于本次提供的 `MF_VAT_ParticleSprites_Simplifed`，不是所有仅有 pos/rot 的 VAT。需要输入材质实例的 Bound Min / Bound Max（每项 X,Y,Z，用逗号分隔）。Position Alpha 存储缩放/密度，rot RGB 在这个函数中作为速度使用，rot Alpha 是 Lower Mask。当前支持单张 HDR Position、Position Alpha 缩放和已提供的函数分支，不支持改成 Rotation Alpha 缩放或任意自定义变体。

本次 Breach 资产的参数：

```
Bound Min: -380, -340, -62.099998
Bound Max: 340, 365, 310
FPS: 24
```

工具恢复每个粒子的中心位置，并保留稳定 id、density、lower_mask、原始 vat_velocity_raw。v 根据轨迹差分计算。OUT_PARTICLES 输出可编辑粒子；OUT_BILLBOARD_PREVIEW 输出面向 VAT_PREVIEW_CAMERA 的几何面片。面片跟随指定相机，不随普通编辑器视口移动自动旋转。

CONTROLS 中可调整 Drop Scale、密度/低处大小混合及预览拉伸。初值取父材质默认：DropScale=0.4、PscaleByDensity=0、PscaleatLowerArea=0、预览速度拉伸=0.05。若 UE 实例覆盖了这些值，请相应调整。由于未提供 MF_TransformVelocity_Simplified 的内部节点，视角速度拉伸采用几何轨迹计算的近似预览，不宣称 UE 像素级一致。

输出是整数纹理帧，尚未复刻 UE 亚帧插值播放、透明裁切、折射和水材质。所有帧重新加载验证，另已检查中心位置与采样数据一致、缩放公式正确、相机变化只改变面片不改变粒子轨迹。已回归验证原来的 36 帧动态重网格模式。

## 启动失败时

如果系统禁用了 VBS，使用 Windows PowerShell 运行：

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "工具所在目录\VATRestore.ps1"
```

工具会自动寻找常规安装位置的 Houdini；也可以手动选择 `Houdini 安装目录\bin\hython.exe`。授权错误会显示在日志中。
