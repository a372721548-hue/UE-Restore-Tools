"""Headless Houdini worker for UE Dynamic Remeshing VAT (HDR positions)."""
import argparse
import json
import math
import pathlib
import sys
import traceback
from datetime import datetime
from uuid import uuid4


def emit(kind, **data):
    print(json.dumps(dict(event=kind, **data), ensure_ascii=True), flush=True)


def restore(config):
    if config.get('mode') == 'particles':
        from particles import restore_particles
        return restore_particles(config, emit)
    import hou
    import numpy as np
    import OpenImageIO as oiio

    paths = {}
    for key in ('mesh', 'lookup', 'position'):
        paths[key] = pathlib.Path(config[key]).resolve()
        if not paths[key].is_file():
            raise ValueError('找不到输入文件：' + str(paths[key]))
    if paths['mesh'].suffix.lower() != '.fbx':
        raise ValueError('目前仅支持从 UE 导出的 FBX 网格。')
    fps = float(config.get('fps', 60))
    if not math.isfinite(fps) or not 1 <= fps <= 1000:
        raise ValueError('帧率必须在 1–1000 之间。')

    def read(path, channels):
        spec = oiio.ImageSpec()
        spec.attribute('oiio:UnassociatedAlpha', 1)
        reader = oiio.ImageInput.open(str(path), spec)
        if not reader:
            raise ValueError('无法读取纹理：' + str(path))
        try:
            image = reader.read_image()
        finally:
            reader.close()
        if image is None or image.ndim != 3 or image.shape[2] < channels:
            raise ValueError(f'{path.name} 需要至少 {channels} 个通道；Lookup 必须保留 Alpha。')
        if not np.isfinite(image).all():
            raise ValueError(path.name + ' 包含无效数值。')
        return image

    emit('status', message='读取网格和纹理…')
    lut, pos = read(paths['lookup'], 4), read(paths['position'], 3)
    hou.hipFile.clear(suppress_save_prompt=True)
    temporary = hou.node('/obj').createNode('geo', 'SOURCE_IMPORT')
    file_node = temporary.createNode('file')
    file_node.parm('file').set(str(paths['mesh']))
    source = file_node.geometry()
    if not source.prims() or any(len(p.vertices()) != 3 for p in source.prims()):
        raise ValueError('输入必须是三角形网格；请从 UE 导出原始 VAT 网格。')
    attr = source.findVertexAttrib('uv')
    point_attr = source.findPointAttrib('uv')
    if not attr and not point_attr:
        raise ValueError('网格缺少 UV0，无法定位 VAT 数据。')
    if attr:
        uv = np.asarray(source.vertexFloatAttribValues('uv')).reshape(-1, attr.size())[:, :2].copy()
    else:
        uv = np.asarray([v.point().attribValue('uv')[:2] for p in source.prims() for v in p.vertices()])
    uv[:, 1] = 1 - uv[:, 1]
    if not np.isfinite(uv).all():
        raise ValueError('网格 UV 包含无效数值。')
    valid = np.all(uv.reshape(-1, 3, 2)[:, :, 1] < .9, axis=1)
    if not valid.any():
        raise ValueError('未找到有效动画三角形；该网格可能不是受支持的 Dynamic Remeshing VAT。')
    bounds = source.boundingBox()
    # Match supplied MF_DynamicRemeshing's embedded bounds rounding.
    mn = np.round(np.asarray(bounds.minvec())[[0, 2, 1]] / 1e-4) * 1e-5
    mx = np.round(np.asarray(bounds.maxvec())[[0, 2, 1]] / 1e-4) * 1e-5
    active = 1 - (np.ceil(mn[:2]) - mn[:2])
    rows = int(round((np.ceil(mn[2]) - mn[2]) * 100))
    active_height = int(round(lut.shape[0] * active[0]))
    if rows <= 0 or active_height <= 0 or active_height % rows:
        raise ValueError('无法从包围盒解析完整帧数。此工具需要保留嵌入数据的 UE 导出网格；不支持已变换或重新建模的 FBX。')
    frames = active_height // rows
    if frames > 10000:
        raise ValueError('解析帧数异常，请检查网格与贴图是否属于同一套资产。')
    denom = 2048 if mx[0] - np.floor(mx[0]) >= .5 else 255
    if mx[1] - np.floor(mx[1]) < .5:
        raise ValueError('检测到非 HDR 位置编码。目前版本只支持单张 HDR Position 的 Dynamic Remeshing VAT。')
    if paths['position'].suffix.lower() not in ('.exr', '.hdr'):
        raise ValueError('HDR Position 请使用原始 EXR/HDR，不能使用 PNG/JPG 替代。')
    real_uv = uv.reshape(-1, 3, 2)[valid]
    if np.any(real_uv < 0) or np.any(real_uv[:, :, 0] >= 1) or np.any(real_uv[:, :, 1] >= 1 / frames + 1e-6):
        raise ValueError('UV0 不符合每帧查找表布局，请核对网格、Lookup 和 Position 的对应关系。')
    emit('status', message=f'已识别 {frames} 帧，每帧 {rows} 行；开始还原…')
    base = pathlib.Path(config['output']).resolve()
    base.mkdir(parents=True, exist_ok=True)
    out = base / ('VAT_Restored_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '_' + uuid4().hex[:6])
    out.mkdir(); (out / 'cache').mkdir()
    emit('output', directory=str(out))
    report = dict(inputs={k: str(v) for k, v in paths.items()}, fps=fps, frames=frames,
                  rows_per_frame=rows, lookup_divisor=denom, format='Dynamic Remeshing HDR',
                  excluded_debug_triangles=int((~valid).sum()), frame_stats=[])
    (out / 'INCOMPLETE.txt').write_text('还原尚未完成。只有收到成功提示后，工程才经过全部帧验证。', encoding='utf-8')
    positions = pos[:, :, :3].reshape(-1, 3)
    for frame in range(1, frames + 1):
        q = uv.copy()
        q[:, 0] *= active[1]
        q[:, 1] = (q[:, 1] + (frame - 1) / frames) * active[0]
        xy = np.floor(q * [lut.shape[1], lut.shape[0]]).astype(np.int64)
        xy = np.clip(xy, [0, 0], [lut.shape[1] - 1, lut.shape[0] - 1])
        rgba = lut[xy[:, 1], xy[:, 0]]
        st = np.stack((rgba[:, 0] + rgba[:, 1] / denom, rgba[:, 2] + rgba[:, 3] / denom), axis=1)
        ids = np.floor(st * [pos.shape[1], pos.shape[0]]).astype(np.int64)
        real_ids = ids.reshape(-1, 3, 2)[valid]
        if np.any(real_ids < 0) or np.any(real_ids >= [pos.shape[1], pos.shape[0]]):
            raise ValueError(f'第 {frame} 帧位置查找越界。可能使用了错误贴图，或 Lookup 的 Alpha/精度已丢失。')
        ids = np.clip(ids, [0, 0], [pos.shape[1] - 1, pos.shape[0] - 1])
        flat = ids[:, 1] * pos.shape[1] + ids[:, 0]
        triangles = (positions[flat][:, [0, 2, 1]] * .01).reshape(-1, 3, 3)
        area = np.linalg.norm(np.cross(triangles[:, 1] - triangles[:, 0], triangles[:, 2] - triangles[:, 0]), axis=1)
        keep = valid & (area > 1e-10)
        unique, inverse = np.unique(flat.reshape(-1, 3)[keep], return_inverse=True)
        points = positions[unique][:, [0, 2, 1]] * .01
        geo = hou.Geometry()
        pts = geo.createPoints(points.tolist())
        for tri in inverse.reshape(-1, 3):
            poly = geo.createPolygon()
            for i in tri:
                poly.addVertex(pts[int(i)])
        geo.addAttrib(hou.attribType.Point, 'vat_texel', 0)
        geo.setPointIntAttribValues('vat_texel', unique.tolist())
        geo.addAttrib(hou.attribType.Prim, 'vat_source_primitive', 0)
        geo.setPrimIntAttribValues('vat_source_primitive', np.flatnonzero(keep).tolist())
        geo.addAttrib(hou.attribType.Global, 'vat_frame', frame)
        geo.saveToFile(str(out / 'cache' / f'vat.{frame:04d}.bgeo.sc'))
        report['frame_stats'].append(dict(frame=frame, points=len(points), triangles=int(keep.sum())))
        emit('progress', value=int(frame / frames * 80), message=f'还原 {frame}/{frames} 帧')
    if not any(s['triangles'] for s in report['frame_stats']):
        raise ValueError('全部帧为空，无法生成有效动画；请核对输入资产。')
    temporary.destroy()
    obj = hou.node('/obj').createNode('geo', 'VAT_RESTORED')
    f = obj.createNode('file', 'READ_ANIMATION')
    f.parm('file').set('$HIP/cache/vat.$F4.bgeo.sc')
    normal = obj.createNode('normal', 'SURFACE_NORMALS'); normal.setInput(0, f)
    end = obj.createNode('null', 'OUT_ANIMATION'); end.setInput(0, normal)
    end.setDisplayFlag(True); end.setRenderFlag(True); obj.layoutChildren()
    hou.setFps(fps); hou.playbar.setFrameRange(1, frames); hou.playbar.setPlaybackRange(1, frames)
    hou.setFrame(1)
    note = obj.createStickyNote('HELP')
    note.setText(f'VAT restored | Frames 1-{frames} | {fps:g} FPS\nScrub timeline or Play. Keep cache folder beside this HIP.\nY-up, metres. Dynamic topology; no point-number interpolation.\nNormals rebuilt. UE shading and additional material deformation are not included.')
    note.setSize(hou.Vector2(7, 3))
    hou.hipFile.save(str(out / 'VAT_Restored.hip'))
    actual_hip = hou.hipFile.path() # Licensing may change the file extension.
    hou.hipFile.load(actual_hip, suppress_save_prompt=True)
    for frame in range(1, frames + 1):
        hou.setFrame(frame)
        g = hou.node('/obj/VAT_RESTORED/OUT_ANIMATION').geometry()
        if len(g.prims()) != report['frame_stats'][frame - 1]['triangles']:
            raise RuntimeError(f'第 {frame} 帧重新加载验证失败。')
        if g.prims() and not (g.findPointAttrib('N') or g.findVertexAttrib('N')):
            raise RuntimeError(f'第 {frame} 帧法线计算失败。')
        emit('progress', value=80 + int(frame / frames * 19), message=f'验证工程 {frame}/{frames} 帧')
    hou.setFrame(1); hou.hipFile.save()
    report['hip_file'] = actual_hip
    report['validation'] = 'All frames reloaded and cooked successfully.'
    (out / 'validation.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    (out / '使用说明.txt').write_text(f'打开 {pathlib.Path(actual_hip).name}，播放 1–{frames} 帧。\n帧率：{fps:g} FPS。单位：米，Y 向上。\n移动工程时请同时移动 cache 文件夹。\n已逐帧加载验证。动态拓扑不能按点编号插值。\n法线重新计算，未还原 UE 水材质或额外材质变形。\n', encoding='utf-8')
    (out / 'INCOMPLETE.txt').unlink()
    emit('success', hip=actual_hip, directory=str(out), frames=frames)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', required=True)
    args = parser.parse_args()
    try:
        restore(json.loads(pathlib.Path(args.config).read_text(encoding='utf-8-sig')))
    except Exception as exc:
        emit('error', message=str(exc))
        traceback.print_exc()
        sys.exit(1)
