﻿param([switch]$SmokeTest, [string]$IntegrationConfig)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$script:worker = $null
$script:nextLine = $null
$script:stderrTask = $null
$script:resultHip = ''
$script:resultDir = ''
$script:jobSucceeded = $false
$script:requestPath = ''
$script:usedHython = ''
$script:fields = @{}
$form = New-Object System.Windows.Forms.Form
$form.Text = 'VAT → Houdini 动画还原'
$form.ClientSize = New-Object System.Drawing.Size(800, 790)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 10)

function Add-Label($text, $x, $y, $width, $height) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $text; $label.SetBounds($x, $y, $width, $height)
    $form.Controls.Add($label)
    return $label
}
$null = Add-Label 'VAT 网格动画还原' 24 18 740 32
$null = Add-Label '选择网格与两张数据贴图，生成可直接播放的 Houdini 工程。' 24 54 745 26
$null = Add-Label '还原类型' 24 84 110 26
$mode = New-Object System.Windows.Forms.ComboBox
$mode.SetBounds(150,82,624,28); $mode.DropDownStyle='DropDownList'
$null=$mode.Items.Add('动态重网格：Lookup + Position')
$null=$mode.Items.Add('粒子面片：Rotation + Position（本次 ParticleSprites 函数）')
$mode.SelectedIndex=0; $form.Controls.Add($mode)

function Browse-Field($key) {
    if ($script:worker) { return }
    if ($key -eq 'output') {
        $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
        $dialog.Description = '选择输出父目录；每次还原都会新建独立文件夹'
        if ($dialog.ShowDialog() -eq 'OK') { $script:fields[$key].Text = $dialog.SelectedPath }
        $dialog.Dispose(); return
    }
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    switch ($key) {
        'mesh' { $dialog.Filter = 'FBX 网格|*.fbx' }
        'lookup' { $dialog.Filter = 'Lookup 数据贴图|*.png;*.exr;*.tga;*.tif;*.tiff|所有文件|*.*' }
        'position' { $dialog.Filter = 'HDR 位置贴图|*.exr;*.hdr' }
        'hython' { $dialog.Filter = 'Houdini 后台程序 (hython.exe)|hython.exe' }
    }
    if ($dialog.ShowDialog() -eq 'OK') {
        $script:fields[$key].Text = $dialog.FileName
        if ($key -eq 'mesh') {
            $dir = Split-Path -Parent $dialog.FileName
            $auxPattern=if($mode.SelectedIndex -eq 1){'_rot[_.]'}else{'_lookup[_.]'}
            foreach ($pair in @(@('lookup',$auxPattern), @('position','_pos[_.]'))) {
                $matches = @(Get-ChildItem -LiteralPath $dir -File | Where-Object { $_.Name -match $pair[1] })
                if ($matches.Count -eq 1) { $script:fields[$pair[0]].Text = $matches[0].FullName }
            }
            if (-not $script:fields['output'].Text) { $script:fields['output'].Text = Join-Path $dir 'Houdini_Restored' }
        }
    }
    $dialog.Dispose()
}
$rows = @(@('mesh','网格 FBX'),@('lookup','Lookup 贴图'),@('position','Position 贴图'),@('output','输出目录'),@('hython','Houdini 程序'))
$y = 126
foreach ($row in $rows) {
    $rowlabel = Add-Label $row[1] 24 $y 125 26
    if($row[0] -eq 'lookup'){$auxLabel=$rowlabel}
    $box = New-Object System.Windows.Forms.TextBox
    $box.SetBounds(150, $y, 530, 27); $form.Controls.Add($box)
    $script:fields[$row[0]] = $box
    $button = New-Object System.Windows.Forms.Button
    $button.Text = '选择…'; $button.Tag = $row[0]; $button.SetBounds(690, $y-1, 84, 30)
    $button.Add_Click({ Browse-Field $this.Tag }); $form.Controls.Add($button)
    $y += 42
}
$installed = @(Get-ChildItem -Path 'C:\Program Files\Side Effects Software\Houdini *\bin\hython.exe' -ErrorAction SilentlyContinue | Sort-Object { try { [version]($_.Directory.Parent.Name -replace '^Houdini ','') } catch { [version]'0.0' } } -Descending)
if ($installed.Count) { $script:fields['hython'].Text = $installed[0].FullName }
$null = Add-Label '播放帧率' 24 340 125 26
$fps = New-Object System.Windows.Forms.NumericUpDown
$fps.SetBounds(150,340,90,27); $fps.Minimum=1; $fps.Maximum=1000; $fps.Value=60; $fps.DecimalPlaces=2
$form.Controls.Add($fps)
$null = Add-Label '请按原动画速度调整。帧数自动读取。' 256 342 520 26
$null = Add-Label '粒子模式参数（按材质实例填写，顺序 X, Y, Z）' 24 380 750 26
$null = Add-Label 'Bound Min' 24 415 125 26
$boundMin=New-Object System.Windows.Forms.TextBox
$boundMin.SetBounds(150,413,624,27);$form.Controls.Add($boundMin)
$null = Add-Label 'Bound Max' 24 450 125 26
$boundMax=New-Object System.Windows.Forms.TextBox
$boundMax.SetBounds(150,448,624,27);$form.Controls.Add($boundMax)
$boundMin.Enabled=$false;$boundMax.Enabled=$false
$null = Add-Label '粒子尺寸使用父材质默认值，生成后可在 CONTROLS 调整；面片是相机朝向预览。' 24 486 750 26
$start = New-Object System.Windows.Forms.Button
$start.Text='开始还原'; $start.SetBounds(24,386,146,38); $form.Controls.Add($start)
$openHip = New-Object System.Windows.Forms.Button
$openHip.Text='打开 Houdini 工程'; $openHip.SetBounds(185,386,190,38); $openHip.Enabled=$false; $form.Controls.Add($openHip)
$openDir = New-Object System.Windows.Forms.Button
$openDir.Text='打开结果文件夹'; $openDir.SetBounds(390,386,166,38); $openDir.Enabled=$false; $form.Controls.Add($openDir)
$progress = New-Object System.Windows.Forms.ProgressBar
$progress.SetBounds(24,440,750,20); $form.Controls.Add($progress)
$status = Add-Label '准备就绪。无需提前打开 Houdini。' 24 472 750 26
$log = New-Object System.Windows.Forms.TextBox
$log.SetBounds(24,506,750,116); $log.Multiline=$true; $log.ScrollBars='Vertical'; $log.ReadOnly=$true
$form.Controls.Add($log)
foreach($control in @($start,$openHip,$openDir,$progress,$status,$log)){$control.Top+=140}
$mode.Add_SelectedIndexChanged({
    if($mode.SelectedIndex -eq 1){$auxLabel.Text='Rotation 贴图';$fps.Value=24}else{$auxLabel.Text='Lookup 贴图';$fps.Value=60}
    $boundMin.Enabled=($mode.SelectedIndex -eq 1);$boundMax.Enabled=($mode.SelectedIndex -eq 1)
    $script:fields['lookup'].Text=''
})
function Log-Line($s) { $log.AppendText($s + [Environment]::NewLine) }
function Handle-Line($s) {
    try { $event = $s | ConvertFrom-Json } catch { Log-Line $s; return }
    switch ($event.event) {
        'status' { $status.Text=$event.message; Log-Line $event.message }
        'progress' { $progress.Value=[Math]::Min(99,[int]$event.value); $status.Text=$event.message }
        'output' { $script:resultDir=$event.directory; Log-Line ('输出：' + $event.directory) }
        'error' { $status.Text='还原失败'; Log-Line $event.message }
        'success' {
            $script:jobSucceeded=$true; $script:resultHip=$event.hip; $script:resultDir=$event.directory
            Log-Line ('成功还原 ' + $event.frames + ' 帧，工程已逐帧验证。')
        }
        default { Log-Line $s }
    }
}
$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 100
$timer.Add_Tick({
    if (-not $script:worker) { return }
    try {
        $count=0
        while ($script:nextLine -and $script:nextLine.IsCompleted -and $count -lt 200) {
            $line=$script:nextLine.GetAwaiter().GetResult()
            if ($null -eq $line) { $script:nextLine=$null; break }
            Handle-Line $line
            $script:nextLine=$script:worker.StandardOutput.ReadLineAsync(); $count++
        }
        if ($script:worker.HasExited -and -not $script:nextLine) {
            $timer.Stop()
            $err=$script:stderrTask.GetAwaiter().GetResult()
            if ($err) { Log-Line $err }
            if ($script:worker.ExitCode -eq 0 -and $script:jobSucceeded) {
                $progress.Value=100; $status.Text='还原完成。可以打开工程播放。'
                $openHip.Enabled=$true; $openDir.Enabled=$true
            } else { $status.Text='未完成还原，请查看下方错误信息。' }
            $script:worker.Dispose(); $script:worker=$null; $start.Enabled=$true
            $mode.Enabled=$true
            foreach($box in $script:fields.Values) { $box.ReadOnly=$false }
            if (Test-Path -LiteralPath $script:requestPath) { Remove-Item -LiteralPath $script:requestPath }
        }
    } catch { $timer.Stop(); Log-Line $_.Exception.ToString(); $status.Text='读取任务状态失败，请重新启动工具。' }
})
$startHandler = {
    try {
        foreach($key in @('mesh','lookup','position','hython')) {
            if (-not (Test-Path -LiteralPath $script:fields[$key].Text -PathType Leaf)) { throw ('请选择有效文件：' + $key) }
        }
        if (-not $script:fields['output'].Text.Trim()) { throw '请选择输出目录。' }
        if ($script:worker) { throw '当前还原尚未结束。' }
        $config=@{mesh=$script:fields['mesh'].Text;lookup=$script:fields['lookup'].Text;position=$script:fields['position'].Text;output=$script:fields['output'].Text;fps=[double]$fps.Value}
        if($mode.SelectedIndex -eq 1){
            $config.mode='particles';$config.rotation=$config.lookup
            foreach($pair in @(@('bound_min',$boundMin.Text),@('bound_max',$boundMax.Text))){
                $values=@($pair[1] -split '[,，\s]+' | Where-Object {$_} | ForEach-Object {[double]::Parse($_,[Globalization.CultureInfo]::InvariantCulture)})
                if($values.Count -ne 3){throw 'Bound Min / Max 各需三个数，用逗号分隔。'}
                $config[$pair[0]]=$values
            }
        }
        $script:requestPath=Join-Path ([IO.Path]::GetTempPath()) ('VATRestore_'+[guid]::NewGuid().ToString('N')+'.json')
        [IO.File]::WriteAllText($script:requestPath,($config | ConvertTo-Json),[Text.UTF8Encoding]::new($false))
        $info=New-Object System.Diagnostics.ProcessStartInfo
        $info.FileName=$script:fields['hython'].Text
        $script:usedHython=$info.FileName
        $info.Arguments='"'+(Join-Path $PSScriptRoot 'restore.py')+'" --config "'+$script:requestPath+'"'
        $info.UseShellExecute=$false; $info.CreateNoWindow=$true
        $info.RedirectStandardOutput=$true; $info.RedirectStandardError=$true
        $info.StandardOutputEncoding=[Text.Encoding]::UTF8; $info.StandardErrorEncoding=[Text.Encoding]::UTF8
        $info.EnvironmentVariables['PYTHONIOENCODING']='utf-8'
        $script:worker=New-Object System.Diagnostics.Process
        $script:worker.StartInfo=$info
        $script:jobSucceeded=$false; $script:resultHip=''; $script:resultDir=''
        $log.Clear();$progress.Value=0;$openHip.Enabled=$false;$openDir.Enabled=$false
        $null=$script:worker.Start()
        $script:nextLine=$script:worker.StandardOutput.ReadLineAsync()
        $script:stderrTask=$script:worker.StandardError.ReadToEndAsync()
        $start.Enabled=$false; foreach($box in $script:fields.Values) { $box.ReadOnly=$true }
        $mode.Enabled=$false
        $status.Text='正在启动 Houdini 后台进程…'; $timer.Start()
    } catch {
        if ($script:worker -and -not $start.Enabled) { Log-Line $_.Exception.Message }
        else { $script:worker=$null; [Windows.Forms.MessageBox]::Show($_.Exception.Message,'无法开始还原') | Out-Null }
    }
}
$start.Add_Click($startHandler)
$openDir.Add_Click({ Start-Process explorer.exe -ArgumentList ('"'+$script:resultDir+'"') })
$openHip.Add_Click({
    $exe=Join-Path (Split-Path -Parent $script:usedHython) 'houdini.exe'
    Start-Process -FilePath $exe -ArgumentList ('"'+$script:resultHip+'"')
})
$form.Add_FormClosing({
    if ($script:worker -and -not $script:worker.HasExited) {
        $answer=[Windows.Forms.MessageBox]::Show('还原仍在进行。退出将终止任务并保留未完成的输出，是否退出？','退出工具','YesNo','Question')
        if ($answer -eq 'Yes') { $script:worker.Kill() } else { $_.Cancel=$true }
    }
})
if ($IntegrationConfig) {
    $testConfig=Get-Content -LiteralPath $IntegrationConfig -Raw -Encoding UTF8 | ConvertFrom-Json
    if($testConfig.mode -eq 'particles'){
        $mode.SelectedIndex=1
        $boundMin.Text=$testConfig.bound_min -join ', '
        $boundMax.Text=$testConfig.bound_max -join ', '
    }
    foreach($key in @('mesh','lookup','position','output')) { $script:fields[$key].Text=$testConfig.$key }
    if($testConfig.mode -eq 'particles'){$script:fields['lookup'].Text=$testConfig.rotation}
    $fps.Value=$testConfig.fps
    & $startHandler
    $deadline=[DateTime]::UtcNow.AddMinutes(3)
    while ($script:worker -and [DateTime]::UtcNow -lt $deadline) {
        [Windows.Forms.Application]::DoEvents()
        Start-Sleep -Milliseconds 50
    }
    if ($script:worker) { $script:worker.Kill(); throw 'UI integration test timeout' }
    if (-not $script:jobSucceeded -or -not $openHip.Enabled) { throw ('UI integration failed: '+$log.Text) }
    Write-Output ('INTEGRATION_OK: '+$script:resultHip)
    $form.Dispose()
} elseif ($SmokeTest) {
    if ($script:fields.Count -ne 5 -or -not $script:fields['hython'].Text) { throw 'UI smoke test failed' }
    Write-Output ('UI_OK: '+$script:fields['hython'].Text)
    $form.Dispose()
} else { [Windows.Forms.Application]::Run($form) }
