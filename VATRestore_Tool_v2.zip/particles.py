"""Decoder for the supplied MF_VAT_ParticleSprites_Simplifed profile."""
import json, pathlib
from datetime import datetime
from uuid import uuid4


def restore_particles(config, emit):
    import hou, numpy as np, OpenImageIO as oi
    paths={k:pathlib.Path(config[k]).resolve() for k in ('mesh','position','rotation')}
    for p in paths.values():
        if not p.is_file(): raise ValueError('找不到输入文件：'+str(p))
    if any(paths[k].suffix.lower() not in ('.exr','.hdr') for k in ('position','rotation')):
        raise ValueError('此粒子模式请使用原始 HDR/EXR Position 和 Rotation 数据贴图。')
    def read(path):
        s=oi.ImageSpec();s.attribute('oiio:UnassociatedAlpha',1)
        f=oi.ImageInput.open(str(path),s)
        if not f: raise ValueError('无法读取：'+str(path))
        try:a=f.read_image()
        finally:f.close()
        if a is None or a.ndim!=3 or a.shape[2]!=4 or not np.isfinite(a).all():
            raise ValueError('粒子模式需要四通道、有效浮点数据：'+str(path))
        return a
    mn=np.asarray(config.get('bound_min',[]),dtype=float)*.1
    mx=np.asarray(config.get('bound_max',[]),dtype=float)*.1
    if mn.shape!=(3,) or mx.shape!=(3,) or not np.isfinite([mn,mx]).all():
        raise ValueError('粒子模式必须填写材质实例的 Bound Min / Max 六个数值。')
    fps=float(config.get('fps',24))
    if not np.isfinite(fps) or not 1<=fps<=1000:raise ValueError('帧率必须在 1–1000 之间。')
    pos,rot=read(paths['position']),read(paths['rotation'])
    if pos.shape!=rot.shape:raise ValueError('Position 与 Rotation 尺寸必须相同。')
    # Same rounding/extra-row decoding as nodes 175–196 of the supplied function.
    fraction=mx[1]-np.floor(mx[1]);flag=int(round(fraction*100))
    if fraction<.5:raise ValueError('粒子模式当前仅支持该函数的单张 HDR 位置编码。')
    active=1-(np.ceil(mn[:2])-mn[:2])
    rowbase=round((np.ceil(mn[2])-mn[2])*100)
    digits=25-abs(flag%50-25);digits-=np.floor(digits/10)
    extra=0 if flag%25<.05 or flag%10<.05 else round(digits)*100
    rows=int(rowbase+extra);height=int(round(pos.shape[0]*active[0]))
    if rows<=0 or height<=0 or height%rows:raise ValueError('包围盒参数与贴图不符，无法确定帧数。')
    frames=height//rows
    if frames>10000 or not np.all((active>0)&(active<=1)):raise ValueError('帧布局参数异常。')
    hou.hipFile.clear(suppress_save_prompt=True)
    obj=hou.node('/obj').createNode('geo','VAT_PARTICLES')
    f=obj.createNode('file','IMPORT_SOURCE');f.parm('file').set(str(paths['mesh']));g=f.geometry()
    attr=g.findVertexAttrib('uv2')
    if not attr:raise ValueError('粒子网格需要第二套 UV（Houdini uv2 / UE TexCoord1）。')
    uv=np.asarray(g.vertexFloatAttribValues('uv2')).reshape(-1,attr.size())[:,:2].copy();uv[:,1]=1-uv[:,1]
    uv=np.unique(uv[uv[:,1]<.9],axis=0)
    xy=np.floor(uv*[active[1]*pos.shape[1],active[0]*pos.shape[0]]).astype(int)
    if not len(xy) or np.any(xy<0) or np.any(xy[:,0]>=pos.shape[1]) or np.any(xy[:,1]>=rows):
        raise ValueError('UV2 不符合给定帧布局。请检查 FBX 与参数。')
    if len(np.unique(xy,axis=0))!=len(xy):raise ValueError('不同粒子 UV 指向同一像素，可能有 UV 精度丢失。')
    maxscale=1/(1-(mx[2]-np.floor(mx[2])))
    base=pathlib.Path(config['output']).resolve();base.mkdir(parents=True,exist_ok=True)
    out=base/('VAT_Particles_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid4().hex[:6]);out.mkdir();(out/'cache').mkdir()
    (out/'INCOMPLETE.txt').write_text('还原尚未完成。',encoding='utf-8')
    emit('output',directory=str(out));emit('status',message=f'识别 {len(xy)} 个粒子、{frames} 帧，保存位置和辅助属性…')
    allpositions=[];report=dict(format='MF_VAT_ParticleSprites_Simplifed',frames=frames,fps=fps,particles=len(xy),rows_per_frame=rows,config=config,frame_stats=[])
    for fr in range(frames):
        a=pos[xy[:,1]+fr*rows,xy[:,0]];b=rot[xy[:,1]+fr*rows,xy[:,0]]
        p=a[:,:3][:,[0,2,1]]*.01;allpositions.append(p)
        geo=hou.Geometry();geo.createPoints(p.tolist())
        for name,default,values in [('id',0,np.arange(len(p))),('density',0.,a[:,3]),('lower_mask',0.,b[:,3]),('vat_velocity_raw',(0.,0.,0.),b[:,:3]),('active',0,(np.linalg.norm(a[:,:3],axis=1)>2).astype(int))]:
            geo.addAttrib(hou.attribType.Point,name,default)
            if isinstance(default,int):geo.setPointIntAttribValues(name,values.reshape(-1).tolist())
            else:geo.setPointFloatAttribValues(name,values.reshape(-1).tolist())
        geo.saveToFile(str(out/'cache'/f'particles.{fr+1:04d}.bgeo.sc'))
        report['frame_stats'].append(dict(frame=fr+1,active=int((np.linalg.norm(a[:,:3],axis=1)>2).sum()),bounds_min=p.min(0).tolist(),bounds_max=p.max(0).tolist()))
        emit('progress',value=int((fr+1)/frames*65),message=f'解码粒子 {fr+1}/{frames} 帧')
    # Derive v from positions: retain raw rot RGB separately rather than assume units.
    for fr in range(frames):
        geo=hou.Geometry();path=out/'cache'/f'particles.{fr+1:04d}.bgeo.sc';geo.loadFromFile(str(path))
        left=max(fr-1,0);right=min(fr+1,frames-1)
        v=(allpositions[right]-allpositions[left])*fps/max(right-left,1)
        geo.addAttrib(hou.attribType.Point,'v',(0.,0.,0.));geo.setPointFloatAttribValues('v',v.reshape(-1).tolist());geo.saveToFile(str(path))
    f.destroy()
    readnode=obj.createNode('file','READ_PARTICLE_CACHE');readnode.parm('file').set('$HIP/cache/particles.$F4.bgeo.sc')
    controls=obj.createNode('null','CONTROLS');controls.setInput(0,readnode)
    templates=controls.parmTemplateGroup()
    for name,label,value in [('drop_scale','Drop Scale',.4),('density_blend','Pscale By Density',0.),('lower_blend','Pscale At Lower Area',0.),('height_stretch','Velocity Stretch (preview)',.05)]:
        templates.append(hou.FloatParmTemplate(name,label,1,default_value=(float(config.get(name,value)),)))
    templates.append(hou.StringParmTemplate('camera','Billboard Camera',1,default_value=('/obj/VAT_PREVIEW_CAMERA',)))
    controls.setParmTemplateGroup(templates)
    wr=obj.createNode('attribwrangle','RESTORE_PARTICLE_SIZE');wr.setInput(0,controls)
    wr.parm('snippet').set(f'''float base=ch("../CONTROLS/drop_scale")*i@active;
float scale=lerp(f@density*{maxscale:.12g}*base,base,ch("../CONTROLS/density_blend"));
scale*=lerp(f@lower_mask,1.0,ch("../CONTROLS/lower_blend"));
f@pscale=max(0,scale*0.1);
''')
    pointsout=obj.createNode('null','OUT_PARTICLES');pointsout.setInput(0,wr)
    cards=obj.createNode('attribwrangle','CAMERA_FACING_CARDS');cards.setInput(0,pointsout)
    cards.parm('snippet').set('''matrix3 cam=matrix3(optransform(chs("../CONTROLS/camera")));
vector right=normalize(set(1,0,0)*cam), up=normalize(set(0,1,0)*cam);
float vx=dot(v@v,right), vy=dot(v@v,up); float speed=sqrt(vx*vx+vy*vy);
vector along=speed>1e-6?normalize(vx*right+vy*up):up;
vector across=normalize(cross(along,normalize(cross(right,up))));
float height=1+speed*ch("../CONTROLS/height_stretch");
if(f@pscale>1e-8){
 int pts[];
 vector corners[]=array(-across-along*height,across-along*height,across+along*height,-across+along*height);
 foreach(vector c;corners){int p=addpoint(0,@P+c*f@pscale);setpointattrib(0,"id",p,i@id);append(pts,p);}
 int prim=addprim(0,"poly",pts);setprimattrib(0,"id",prim,i@id);
}
removepoint(0,@ptnum);
''')
    normal=obj.createNode('normal','NORMALS');normal.setInput(0,cards)
    output=obj.createNode('null','OUT_BILLBOARD_PREVIEW');output.setInput(0,normal);output.setDisplayFlag(True);output.setRenderFlag(True)
    camera=hou.node('/obj').createNode('cam','VAT_PREVIEW_CAMERA');camera.parmTuple('t').set((0,2,11));camera.parmTuple('r').set((-6,0,0))
    obj.layoutChildren()
    note=obj.createStickyNote('README');note.setText('Particle VAT: exact sampled centres and raw density/mask attributes.\nOUT_PARTICLES = editable particle animation with stable id and derived v.\nOUT_BILLBOARD_PREVIEW = cards facing VAT_PREVIEW_CAMERA.\nCONTROLS edits size and preview stretch. Parent defaults used.\nPreview is not the UE transparency/refraction shader.\nrot RGB preserved as vat_velocity_raw; v derived from positions.');note.setSize(hou.Vector2(8,3))
    hou.setFps(fps);hou.playbar.setFrameRange(1,frames);hou.playbar.setPlaybackRange(1,frames);hou.setFrame(1)
    hou.hipFile.save(str(out/'VAT_Particles_Restored.hip'));hip=hou.hipFile.path()
    hou.hipFile.load(hip,suppress_save_prompt=True)
    for fr in range(1,frames+1):
        hou.setFrame(fr);geo=hou.node('/obj/VAT_PARTICLES/OUT_PARTICLES').geometry()
        if len(geo.points())!=len(xy) or not np.array_equal(np.asarray(geo.pointFloatAttribValues('P')).reshape(-1,3),allpositions[fr-1]):raise RuntimeError('缓存校验失败')
        cardgeo=hou.node('/obj/VAT_PARTICLES/OUT_BILLBOARD_PREVIEW').geometry()
        if not np.isfinite(cardgeo.pointFloatAttribValues('P')).all():raise RuntimeError('面片坐标无效')
        emit('progress',value=65+int(fr/frames*34),message=f'验证工程 {fr}/{frames} 帧')
    hou.setFrame(min(10,frames));hou.hipFile.save()
    report['hip_file']=hip;report['validation']='Every frame reloaded: positions bit-identical, point count stable, billboard geometry finite.'
    (out/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'使用说明.txt').write_text(f'播放 1–{frames} 帧，{fps:g} FPS。\nOUT_PARTICLES 是解码后的真实粒子轨迹，含 id、density、lower_mask、vat_velocity_raw、v、pscale。\nOUT_BILLBOARD_PREVIEW 是面向 VAT_PREVIEW_CAMERA 的面片预览。转动普通视口不会改变面片朝向，请调整该相机。\nCONTROLS 可调整粒子大小和拉伸。使用所提供父材质默认尺寸参数；视角拉伸为预览实现，不是 UE 像素级复刻。\n未恢复透明裁切、水材质、折射。只读整数纹理帧，不复刻 UE 亚帧插值播放。\n移动工程时一起移动 cache 文件夹。',encoding='utf-8')
    (out/'INCOMPLETE.txt').unlink();emit('success',hip=hip,directory=str(out),frames=frames)
