"""Bounded UE5 package-summary reader, installed-engine selection and module cache."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
from uuid import uuid4


class Reader:
    def __init__(self, path):
        with open(path,'rb') as f: self.data=f.read(1024*1024)
        self.pos=0
    def take(self,n):
        if n<0 or self.pos+n>len(self.data):raise ValueError('uasset 文件头不完整或结构异常。')
        value=self.data[self.pos:self.pos+n];self.pos+=n;return value
    def number(self,fmt='i'):return struct.unpack('<'+fmt,self.take(struct.calcsize('<'+fmt)))[0]
    def string(self):
        n=self.number()
        if abs(n)>65536:raise ValueError('uasset 字符串长度异常。')
        if not n:return ''
        return self.take(abs(n)*(2 if n<0 else 1)).decode('utf-16-le' if n<0 else 'utf-8',errors='strict').rstrip('\0')
    def engine_version(self):
        version=[self.number('H') for _ in range(3)];cl=self.number('I');branch=self.string()
        if version[0] not in (0,4,5):raise ValueError('uasset 引擎版本字段异常。')
        return dict(version=version,changelist=cl,branch=branch)


def read_asset_version(path):
    r=Reader(path)
    if r.number('I')!=0x9E2A83C1:raise ValueError('不是受支持的未烹饪 uasset 文件（文件头标识不符）。')
    legacy=r.number()
    if legacy not in (-8,-9):
        return dict(saved=None,compatible=None,reason='此包头格式未纳入识别；需要工程版本或手动选择引擎。')
    r.number();ue4=r.number();ue5=r.number();licensee=r.number()
    result=dict(saved=None,compatible=None,ue4=ue4,ue5=ue5,licensee=licensee)
    if ue4==ue5==licensee==0:
        return dict(result,reason='资产未记录包格式版本，无法可靠读取保存版本。')
    if ue4<522 or not 1000<=ue5<=1018:
        return dict(result,reason='包格式版本超出当前结构解析范围，使用工程版本或手动选择。')
    if ue5>=1016:r.take(20);r.number() # SavedHash, TotalHeaderSize
    custom=r.number()
    if not 0<=custom<=4096:raise ValueError('uasset 自定义版本数量异常。')
    r.take(custom*20)
    if ue5<1016:r.number()
    r.string();flags=r.number('I')
    if flags & 0x200:raise ValueError('检测到 Cooked 包，本工具需要编辑器中的原始 Geometry Cache 资产。')
    filtered=bool(flags&0x80000000)
    r.take(8) # names
    if ue5>=1008:r.take(8)
    if not filtered:r.string() # localization
    r.take(8+8+8) # gatherable text, exports, imports
    if ue5>=1015:r.take(16)
    if ue5>=1014:r.take(4)
    r.take(4+8+4+4) # depends, soft references, searchable, thumbnail
    if ue5>=1018:r.take(8)
    if ue5<1016:r.take(16)
    if not filtered:r.take(16) # persistent guid
    generations=r.number()
    if not 0<=generations<=65536:raise ValueError('uasset 代数记录异常。')
    r.take(generations*8)
    result['saved']=r.engine_version();result['compatible']=r.engine_version()
    if not result['saved']['version'][0]:result['reason']='资产的保存引擎版本字段为空。'
    return result


def project_info(asset):
    for folder in Path(asset).resolve().parents:
        if folder.name.lower()=='content':
            candidates=list(folder.parent.glob('*.uproject'))
            # Also locate the project for assets stored inside a project plugin.
            if not candidates:
                for parent in folder.parent.parents:
                    candidates=list(parent.glob('*.uproject'))
                    if candidates:break
            if len(candidates)==1:
                p=candidates[0];data=json.loads(p.read_text(encoding='utf-8-sig'))
                return dict(path=str(p),association=str(data.get('EngineAssociation','')))
            break
    return None


def engine_info(exe):
    exe=Path(exe).resolve()
    if exe.name.lower()!='unrealeditor-cmd.exe' or not exe.is_file():raise ValueError('请选择 UnrealEditor-Cmd.exe。')
    engine=exe.parents[2]
    v=json.loads((engine/'Build/Build.version').read_text(encoding='utf-8-sig'))
    buildid=json.loads((exe.parent/'UnrealEditor.modules').read_text(encoding='utf-8-sig'))['BuildId']
    return dict(exe=str(exe),root=str(engine.parent),version=[v[k] for k in ('MajorVersion','MinorVersion','PatchVersion')],build_id=buildid)


def discover_engines():
    roots=set();associations={}
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,r'Software\Epic Games\Unreal Engine\Builds') as key:
            for i in range(winreg.QueryInfoKey(key)[1]):
                name,value,_=winreg.EnumValue(key,i);roots.add(value);associations[name]=value
    except OSError:pass
    try:
        import winreg
        with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE,r'SOFTWARE\EpicGames\Unreal Engine') as key:
            for i in range(winreg.QueryInfoKey(key)[0]):
                name=winreg.EnumKey(key,i)
                with winreg.OpenKey(key,name) as sub:roots.add(winreg.QueryValueEx(sub,'InstalledDirectory')[0])
    except OSError:pass
    launcher=Path(os.environ.get('PROGRAMDATA','C:/ProgramData'))/'Epic/UnrealEngineLauncher/LauncherInstalled.dat'
    if launcher.is_file():
        try:roots.update(x['InstallLocation'] for x in json.loads(launcher.read_text())['InstallationList'] if x.get('AppName','').startswith('UE_'))
        except (ValueError,KeyError):pass
    roots.update(str(p) for p in Path(os.environ.get('ProgramFiles','C:/Program Files'),'Epic Games').glob('UE_*'))
    for drive in ('C:/','D:/','E:/','F:/'):
        roots.update(str(p) for p in Path(drive).glob('UE_*') if p.is_dir())
    engines=[]
    for root in roots:
        try:
            e=engine_info(Path(root)/'Engine/Binaries/Win64/UnrealEditor-Cmd.exe')
            e['associations']=[k for k,v in associations.items() if Path(v).resolve()==Path(root).resolve()]
            if e['exe'].lower() not in {x['exe'].lower() for x in engines}:engines.append(e)
        except (OSError,ValueError,KeyError):pass
    return engines


def select_engine(asset,manual=''):
    info=read_asset_version(asset);project=project_info(asset);installed=discover_engines()
    saved=info.get('saved');version=saved['version'] if saved and saved['version'][0] else None
    association=project['association'] if project else ''
    match=re.fullmatch(r'(\d+)\.(\d+)(?:\.(\d+))?',association)
    project_version=[int(match[1]),int(match[2]),int(match[3] or 0)] if match else None
    target=version
    if project_version and (not target or project_version[:2]>target[:2]):target=project_version
    chosen=None
    if manual:
        chosen=engine_info(manual)
        if version and chosen['version']<version:raise ValueError('所选引擎比资产记录的保存版本旧，不能安全读取。')
    else:
        custom=[e for e in installed if association in e.get('associations',[]) and association and (not version or e['version']>=version)]
        candidates=custom or [e for e in installed if target and e['version'][:2]==target[:2] and (not version or e['version']>=version)]
        if candidates:chosen=max(candidates,key=lambda e:e['version'])
    return dict(asset=info,project=project,selected=chosen,installed=installed,
                target=target,manual=bool(manual),
                message=('已匹配 UE '+'.'.join(map(str,chosen['version']))) if chosen else '未找到可靠匹配的已安装引擎，请手动选择或安装对应版本。')


def prepare_module(engine,template,cache_root,emit):
    template=Path(template);cache_root=Path(cache_root)
    bundled=json.loads((template/'Binaries/Win64/UnrealEditor.modules').read_text())['BuildId']
    if bundled==engine['build_id']:
        emit('status',message='使用随工具附带的匹配提取模块。');return template
    digest=hashlib.sha256()
    for p in sorted((template/'Source').rglob('*')):
        if p.is_file():digest.update(p.relative_to(template).as_posix().encode());digest.update(p.read_bytes())
    digest.update(engine['build_id'].encode())
    key='UE_'+'.'.join(map(str,engine['version']))+'_'+digest.hexdigest()[:16]
    cache=cache_root/key;stamp=cache/'READY.json'
    if stamp.is_file() and (cache/'Binaries/Win64/UnrealEditor-CacheExtract.dll').is_file():
        modules=json.loads((cache/'Binaries/Win64/UnrealEditor.modules').read_text())
        if modules['BuildId']==engine['build_id']:
            emit('status',message='复用此前编译的提取模块。');return cache
    cache_root.mkdir(parents=True,exist_ok=True)
    work=cache_root/(key+'_build_'+uuid4().hex[:6]);work.mkdir()
    shutil.copytree(template/'Source',work/'Source')
    data=json.loads((template/'CacheExtract.uproject').read_text());data['EngineAssociation']='.'.join(map(str,engine['version'][:2]))
    (work/'CacheExtract.uproject').write_text(json.dumps(data),encoding='utf-8')
    engine_root=Path(engine['root'])/'Engine'
    dotnet=list((engine_root/'Binaries/ThirdParty/DotNet').glob('*/win-x64/dotnet.exe'))
    ubt=engine_root/'Binaries/DotNET/UnrealBuildTool/UnrealBuildTool.dll'
    if not dotnet or not ubt.is_file():raise ValueError('找不到所选引擎的编译工具，请检查 UE 安装完整性。')
    log=work/'build.log'
    emit('status',message='首次适配 UE '+'.'.join(map(str,engine['version']))+'，正在编译提取模块（需要 C++ 编译环境）…')
    cmd=[str(sorted(dotnet)[-1]),str(ubt),'CacheExtractEditor','Win64','Development',
         '-Project='+str(work/'CacheExtract.uproject'),'-WaitMutex','-NoHotReloadFromIDE']
    with log.open('w',encoding='utf-8') as f:
        child=subprocess.Popen(cmd,stdout=f,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        while True:
            try:code=child.wait(timeout=30);break
            except subprocess.TimeoutExpired:emit('status',message='仍在编译首次使用的引擎模块，请稍候…')
    if code:raise RuntimeError('模块编译失败，请检查 C++ 工具链或新版 UE 接口。编译日志：'+str(log))
    modules=work/'Binaries/Win64/UnrealEditor.modules'
    if not modules.is_file() or json.loads(modules.read_text())['BuildId']!=engine['build_id']:
        raise RuntimeError('编译产物与引擎 BuildId 不匹配，停止提取。')
    # Publish only portable inputs and runtime module files, not Intermediate/PDB.
    published=cache_root/(key+'_ready_'+uuid4().hex[:6]);published.mkdir()
    shutil.copytree(work/'Source',published/'Source');shutil.copy2(work/'CacheExtract.uproject',published)
    dest=published/'Binaries/Win64';dest.mkdir(parents=True)
    for name in ('UnrealEditor.modules','UnrealEditor-CacheExtract.dll','CacheExtractEditor.target'):
        shutil.copy2(work/'Binaries/Win64'/name,dest/name)
    (published/'READY.json').write_text(json.dumps(dict(engine=engine,source_hash=digest.hexdigest())),encoding='utf-8')
    if not cache.exists():published.rename(cache);return cache
    return published # Another job may already have published; do not overwrite.
