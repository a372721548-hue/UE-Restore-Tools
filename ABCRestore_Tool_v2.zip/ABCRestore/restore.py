"""Standalone Geometry Cache extraction pipeline; no VAT dependencies."""
import argparse
import hashlib
import json
import pathlib
import shutil
import subprocess
import sys
import traceback
from datetime import datetime
from uuid import uuid4


def emit(event, **values):
    print(json.dumps(dict(event=event,**values),ensure_ascii=True),flush=True)


def validate(config):
    paths={k:pathlib.Path(config[k]).resolve() for k in ('asset','hython')}
    for key,p in paths.items():
        if not p.is_file(): raise ValueError('找不到文件：'+str(p))
    if paths['asset'].suffix.lower()!='.uasset': raise ValueError('请选择 UE Geometry Cache 的 .uasset 文件。')
    if paths['hython'].name.lower()!='hython.exe': raise ValueError('请选择 Houdini 的 hython.exe。')
    template=pathlib.Path(__file__).parent/'Extractor'
    from engine_support import select_engine
    detection=select_engine(paths['asset'],config.get('engine','').strip())
    if not detection['selected']:raise ValueError(detection['message'])
    paths['engine']=pathlib.Path(detection['selected']['exe'])
    paths['detection']=detection
    return paths,template


def run(config):
    paths,template=validate(config)
    base=pathlib.Path(config['output']).resolve();base.mkdir(parents=True,exist_ok=True)
    out=base/(paths['asset'].stem+'_ABC_'+datetime.now().strftime('%Y%m%d_%H%M%S')+'_'+uuid4().hex[:6])
    out.mkdir();work=out/'_extraction';work.mkdir()
    (out/'INCOMPLETE.txt').write_text('任务尚未完成。',encoding='utf-8')
    (work/'request.json').write_text(json.dumps(config,ensure_ascii=False,indent=2),encoding='utf-8')
    emit('output',directory=str(out));emit('status',message='复制资产到独立提取工程…')
    detection=paths['detection']
    (work/'engine_detection.json').write_text(json.dumps(detection,ensure_ascii=False,indent=2),encoding='utf-8')
    emit('detection',**detection)
    from engine_support import prepare_module
    template=prepare_module(detection['selected'],template,config.get('module_cache',str(pathlib.Path(__file__).parent/'ModuleCache')),emit)
    project=work/'UEProject';shutil.copytree(template,project)
    asset=paths['asset'];relative=pathlib.Path('Imported')/asset.name
    for parent in asset.parents:
        if parent.name.lower()=='content':relative=asset.relative_to(parent);break
    target=project/'Content'/relative;target.parent.mkdir(parents=True,exist_ok=True)
    digest=hashlib.sha256(asset.read_bytes()).hexdigest()
    shutil.copy2(asset,target)
    for suffix in ('.uexp','.ubulk','.uptnl'):
        companion=asset.with_suffix(suffix)
        if companion.exists():shutil.copy2(companion,target.with_suffix(suffix))
    package='/Game/'+relative.with_suffix('').as_posix()
    object_path=package+'.'+asset.stem
    raw=work/'raw';log=work/'unreal.log'
    command=[str(paths['engine']),str(project/'CacheExtract.uproject'),'-run=CacheExtract',
             '-Asset='+object_path,'-Out='+str(raw),'-Unattended','-NullRHI','-NoSplash','-abslog='+str(log)]
    emit('status',message='UE 正在加载并解码几何缓存…')
    with (work/'unreal_console.log').open('w',encoding='utf-8') as console:
        child=subprocess.Popen(command,stdout=console,stderr=subprocess.STDOUT,creationflags=subprocess.CREATE_NO_WINDOW)
        code=child.wait()
    if code or not (raw/'manifest.json').is_file():
        raise RuntimeError('UE 解码失败。请确认资产类型、引擎版本及配套 .ubulk/.uexp 文件完整。详细日志：'+str(log))
    if hashlib.sha256(asset.read_bytes()).hexdigest()!=digest:
        raise RuntimeError('处理期间源资产内容发生变化；请在资产保存完成后重试。')
    emit('progress',value=25,message='缓存解码完成，开始生成 Houdini 工程…')
    from convert import convert
    result=convert(raw,out,emit)
    emit('success',**result)


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--config');parser.add_argument('--detect');args=parser.parse_args()
    try:
        if args.detect:
            from engine_support import select_engine
            emit('detection',**select_engine(args.detect))
        elif args.config:run(json.loads(pathlib.Path(args.config).read_text(encoding='utf-8-sig')))
        else:raise ValueError('需要 --config 或 --detect 参数。')
    except Exception as exc:
        emit('error',message=str(exc));traceback.print_exc();sys.exit(1)
