#include "CacheExtractCommandlet.h"
#include "Modules/ModuleManager.h"
#include "GeometryCache.h"
#include "GeometryCacheTrackStreamable.h"
#include "GeometryCacheMeshData.h"
#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "HAL/FileManager.h"
#include "Serialization/JsonWriter.h"
#include "Serialization/JsonSerializer.h"
IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, CacheExtract, "CacheExtract");
UCacheExtractCommandlet::UCacheExtractCommandlet(){IsClient=false;IsServer=false;IsEditor=true;LogToConsole=true;}
template<typename T> static bool WriteArray(const FString& Path,const TArray<T>& A){
 TUniquePtr<FArchive> F(IFileManager::Get().CreateFileWriter(*Path));
 if(!F)return false;
 if(A.Num())F->Serialize(const_cast<T*>(A.GetData()),int64(A.Num())*sizeof(T));
 F->Close();return !F->IsError();
}
int32 UCacheExtractCommandlet::Main(const FString& Params){
 FString Asset,Out;FParse::Value(*Params,TEXT("Asset="),Asset);FParse::Value(*Params,TEXT("Out="),Out);
 UGeometryCache* Cache=LoadObject<UGeometryCache>(nullptr,*Asset);
 if(!Cache||Out.IsEmpty()){UE_LOG(LogTemp,Error,TEXT("GC_EXPORT invalid asset/output %s"),*Asset);return 1;}
 IFileManager::Get().MakeDirectory(*Out,true);
 auto Root=MakeShared<FJsonObject>();Root->SetStringField(TEXT("asset"),Asset);
 Root->SetNumberField(TEXT("start_frame"),Cache->GetStartFrame());Root->SetNumberField(TEXT("end_frame"),Cache->GetEndFrame());Root->SetNumberField(TEXT("duration"),Cache->CalculateDuration());
 TArray<TSharedPtr<FJsonValue>> Tracks;
 for(int32 Ti=0;Ti<Cache->Tracks.Num();++Ti){
  auto* T=Cast<UGeometryCacheTrackStreamable>(Cache->Tracks[Ti]);
  if(!T){UE_LOG(LogTemp,Error,TEXT("GC_EXPORT unsupported track"));return 2;}
  const int32 Last=T->FindSampleIndexFromTime(T->GetMaxSampleTime(),false);
  auto Track=MakeShared<FJsonObject>();Track->SetStringField(TEXT("name"),T->GetName());Track->SetNumberField(TEXT("duration"),T->GetDuration());
  TArray<TSharedPtr<FJsonValue>> Samples;
  for(int32 Si=0;Si<=Last;++Si){
   FGeometryCacheMeshData M;if(!T->GetMeshDataAtSampleIndex(Si,M)){UE_LOG(LogTemp,Error,TEXT("GC_EXPORT decode failed %d %d"),Ti,Si);return 3;}
   float Time=T->GetSampleInfo(Si).SampleTime;
   auto S=MakeShared<FJsonObject>();S->SetNumberField(TEXT("time"),Time);S->SetNumberField(TEXT("vertices"),M.Positions.Num());S->SetNumberField(TEXT("indices"),M.Indices.Num());S->SetBoolField(TEXT("visible"),T->GetVisibilitySample(Time,false).bVisibilityState);
   FString Prefix=FString::Printf(TEXT("track%02d_sample%04d"),Ti,Si);S->SetStringField(TEXT("prefix"),Prefix);
   if(!WriteArray(Out/Prefix+TEXT(".P"),M.Positions)||!WriteArray(Out/Prefix+TEXT(".I"),M.Indices))return 4;
   if(M.VertexInfo.bHasUV0 && M.TextureCoordinates.Num()==M.Positions.Num()) {if(!WriteArray(Out/Prefix+TEXT(".UV"),M.TextureCoordinates))return 4;S->SetBoolField(TEXT("uv"),true);}
   if(M.VertexInfo.bHasTangentZ && M.TangentsZ.Num()==M.Positions.Num()){
    TArray<FVector3f> N;for(auto& V:M.TangentsZ)N.Add(V.ToFVector3f());if(!WriteArray(Out/Prefix+TEXT(".N"),N))return 4;S->SetBoolField(TEXT("normals"),true);
   }
   if(M.VertexInfo.bHasColor0 && M.Colors.Num()==M.Positions.Num()){if(!WriteArray(Out/Prefix+TEXT(".C"),M.Colors))return 4;S->SetBoolField(TEXT("colors"),true);}
   FMatrix Matrix=FMatrix::Identity;int32 MatrixIndex=INDEX_NONE;T->UpdateMatrixData(Time,false,MatrixIndex,Matrix);
   TArray<TSharedPtr<FJsonValue>> Values;for(int R=0;R<4;++R)for(int C=0;C<4;++C)Values.Add(MakeShared<FJsonValueNumber>(Matrix.M[R][C]));S->SetArrayField(TEXT("matrix"),Values);
   TArray<TSharedPtr<FJsonValue>> Batches;for(auto& B:M.BatchesInfo){auto J=MakeShared<FJsonObject>();J->SetNumberField(TEXT("start"),B.StartIndex);J->SetNumberField(TEXT("triangles"),B.NumTriangles);J->SetNumberField(TEXT("material"),B.MaterialIndex);Batches.Add(MakeShared<FJsonValueObject>(J));}S->SetArrayField(TEXT("batches"),Batches);
   Samples.Add(MakeShared<FJsonValueObject>(S));
   UE_LOG(LogTemp,Display,TEXT("GC_EXPORT track=%d sample=%d time=%g vertices=%d triangles=%d"),Ti,Si,Time,M.Positions.Num(),M.Indices.Num()/3);
  }
  Track->SetArrayField(TEXT("samples"),Samples);Tracks.Add(MakeShared<FJsonValueObject>(Track));
 }
 Root->SetArrayField(TEXT("tracks"),Tracks);FString Json;auto Writer=TJsonWriterFactory<>::Create(&Json);FJsonSerializer::Serialize(Root,Writer);
 if(!FFileHelper::SaveStringToFile(Json,*(Out/TEXT("manifest.json")),FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM))return 5;
 UE_LOG(LogTemp,Display,TEXT("GC_EXPORT SUCCESS tracks=%d duration=%g"),Tracks.Num(),Cache->CalculateDuration());return 0;
}
