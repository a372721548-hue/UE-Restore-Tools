using UnrealBuildTool;
public class CacheExtract : ModuleRules {
 public CacheExtract(ReadOnlyTargetRules Target) : base(Target) {
  PCHUsage=PCHUsageMode.UseExplicitOrSharedPCHs;
  PublicDependencyModuleNames.AddRange(new string[]{"Core","CoreUObject","Engine","UnrealEd","GeometryCache","Json","RenderCore"});
 }
}
