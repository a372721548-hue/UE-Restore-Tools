#pragma once
#include "Commandlets/Commandlet.h"
#include "CacheExtractCommandlet.generated.h"
UCLASS()
class UCacheExtractCommandlet : public UCommandlet {
 GENERATED_BODY()
public:
 UCacheExtractCommandlet();
 virtual int32 Main(const FString& Params) override;
};
