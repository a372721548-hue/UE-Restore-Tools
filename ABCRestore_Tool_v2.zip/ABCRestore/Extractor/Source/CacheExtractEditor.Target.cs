using UnrealBuildTool;
public class CacheExtractEditorTarget : TargetRules {
 public CacheExtractEditorTarget(TargetInfo Target) : base(Target) {
  Type=TargetType.Editor; DefaultBuildSettings=BuildSettingsVersion.Latest;
  ExtraModuleNames.Add("CacheExtract");
 }
}
