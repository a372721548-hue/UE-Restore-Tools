﻿param([switch]$SmokeTest,[string]$IntegrationConfig)
$ErrorActionPreference='Stop'
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[Windows.Forms.Application]::EnableVisualStyles()
$script:fields=@{};$script:worker=$null;$script:lineTask=$null;$script:errTask=$null
$script:success=$false;$script:result=$null;$script:usedHython='';$script:request=''
$script:detecting=$false
$form=New-Object Windows.Forms.Form
$form.Text='ABC Restore · UE 几何缓存还原（独立工具）'
$form.ClientSize=New-Object Drawing.Size(830,580)
$form.StartPosition='CenterScreen';$form.FormBorderStyle='FixedSingle';$form.MaximizeBox=$false
$form.Font=New-Object Drawing.Font('Microsoft YaHei UI',10)
function Label($text,$x,$y,$w,$h){
 $c=New-Object Windows.Forms.Label;$c.Text=$text;$c.SetBounds($x,$y,$w,$h);$form.Controls.Add($c);return $c
}
$null=Label 'UE Geometry Cache → ABC / Houdini' 24 18 780 30
$null=Label '选择几何缓存 .uasset，生成独立 ABC 和可播放的 Houdini 工程。' 24 54 780 26
$null=Label '自动识别保存版本与工程版本；首次使用新引擎时自动编译提取模块。' 24 82 652 26
$detect=New-Object Windows.Forms.Button;$detect.Text='识别版本';$detect.SetBounds(690,78,114,30);$form.Controls.Add($detect)
function Browse($key){
 if($script:worker){return}
 if($key -eq 'output'){
  $d=New-Object Windows.Forms.FolderBrowserDialog
  $d.Description='选择输出父目录，每次还原都会新建结果文件夹'
  if($d.ShowDialog() -eq 'OK'){$script:fields[$key].Text=$d.SelectedPath}
 }else{
  $d=New-Object Windows.Forms.OpenFileDialog
  switch($key){
   'asset'{$d.Filter='UE 几何缓存资产|*.uasset'}
   'engine'{$d.Filter='UE 后台程序|UnrealEditor-Cmd.exe'}
   'hython'{$d.Filter='Houdini 后台程序|hython.exe'}
  }
  if($d.ShowDialog() -eq 'OK'){
   $script:fields[$key].Text=$d.FileName
   if($key -eq 'asset' -and -not $script:fields['output'].Text){$script:fields['output'].Text=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'ABC_Restored'}
   if($key -eq 'asset'){StartDetection}
  }
 }
 $d.Dispose()
}
$y=124
foreach($row in @(@('asset','几何缓存资产'),@('engine','UE（留空自动）'),@('hython','Houdini 程序'),@('output','输出父目录'))){
 $null=Label $row[1] 24 $y 128 26
 $box=New-Object Windows.Forms.TextBox;$box.SetBounds(155,$y,550,27);$form.Controls.Add($box);$script:fields[$row[0]]=$box
 $b=New-Object Windows.Forms.Button;$b.Text='选择…';$b.Tag=$row[0];$b.SetBounds(716,$y-1,88,30);$b.Add_Click({Browse $this.Tag});$form.Controls.Add($b)
 $y+=42
}
$installed=@(Get-ChildItem 'C:\Program Files\Side Effects Software\Houdini *\bin\hython.exe' -ErrorAction SilentlyContinue | Sort-Object {try{[version]($_.Directory.Parent.Name -replace '^Houdini ','')}catch{[version]'0.0'}} -Descending)
if($installed.Count){$script:fields['hython'].Text=$installed[0].FullName}
$start=New-Object Windows.Forms.Button;$start.Text='开始还原';$start.SetBounds(24,303,145,38);$form.Controls.Add($start)
$openHip=New-Object Windows.Forms.Button;$openHip.Text='打开 Houdini 工程';$openHip.SetBounds(184,303,190,38);$openHip.Enabled=$false;$form.Controls.Add($openHip)
$openABC=New-Object Windows.Forms.Button;$openABC.Text='查看 ABC 文件';$openABC.SetBounds(390,303,160,38);$openABC.Enabled=$false;$form.Controls.Add($openABC)
$openDir=New-Object Windows.Forms.Button;$openDir.Text='打开输出目录';$openDir.SetBounds(565,303,160,38);$openDir.Enabled=$false;$form.Controls.Add($openDir)
$bar=New-Object Windows.Forms.ProgressBar;$bar.SetBounds(24,359,780,20);$form.Controls.Add($bar)
$status=Label '就绪。无需提前打开 UE 或 Houdini。' 24 392 780 26
$log=New-Object Windows.Forms.TextBox;$log.SetBounds(24,431,780,126);$log.Multiline=$true;$log.ReadOnly=$true;$log.ScrollBars='Vertical';$form.Controls.Add($log)
function LogLine($text){$log.AppendText($text+[Environment]::NewLine)}
function HandleLine($text){
 try{$e=$text|ConvertFrom-Json}catch{LogLine $text;return}
 switch($e.event){
  'status'{$status.Text=$e.message;LogLine $e.message}
  'progress'{$bar.Value=[Math]::Min(99,[int]$e.value);$status.Text=$e.message}
  'output'{LogLine ('输出目录：'+$e.directory)}
  'detection'{
   $saved=if($e.asset.saved -and $e.asset.saved.version[0]){$e.asset.saved.version -join '.'}else{'未记录/不可确定'}
   $project=if($e.project){$e.project.association}else{'未找到所属工程'}
   LogLine ('资产保存版本：'+$saved+'；工程版本：'+$project)
   if($e.asset.reason){LogLine $e.asset.reason}
   LogLine $e.message
   if($e.selected){LogLine ('匹配引擎：'+$e.selected.exe)}
   $status.Text=$e.message
  }
  'error'{$status.Text='还原失败';LogLine $e.message}
  'success'{$script:success=$true;$script:result=$e;LogLine ('已生成并验证 '+$e.frames+' 帧，'+$e.fps+' FPS。')}
  default{LogLine $text}
 }
}
$timer=New-Object Windows.Forms.Timer;$timer.Interval=100
$timer.Add_Tick({
 if(-not $script:worker){return}
 try{
  $count=0
  while($script:lineTask -and $script:lineTask.IsCompleted -and $count -lt 200){
   $line=$script:lineTask.GetAwaiter().GetResult()
   if($null -eq $line){$script:lineTask=$null;break}
   HandleLine $line;$script:lineTask=$script:worker.StandardOutput.ReadLineAsync();$count++
  }
  if($script:worker.HasExited -and -not $script:lineTask){
   $timer.Stop();$err=$script:errTask.GetAwaiter().GetResult();if($err){LogLine $err}
   if($script:detecting){
    if($script:worker.ExitCode -ne 0){$status.Text='版本识别失败，请查看日志。'}
    $script:detecting=$false
   }elseif($script:worker.ExitCode -eq 0 -and $script:success){
    $bar.Value=100;$status.Text='还原完成：ABC 和 Houdini 工程均已逐帧验证。'
    $openHip.Enabled=$true;$openABC.Enabled=$true;$openDir.Enabled=$true
   }else{$script:success=$false;$status.Text='还原未完成，请查看错误信息及输出目录内的诊断日志。'}
   $script:worker.Dispose();$script:worker=$null;$start.Enabled=$true;$detect.Enabled=$true
   foreach($b in $script:fields.Values){$b.ReadOnly=$false}
   if($script:request -and (Test-Path -LiteralPath $script:request)){Remove-Item -LiteralPath $script:request}
  }
 }catch{$timer.Stop();$status.Text='任务状态读取失败。';LogLine $_.Exception.ToString()}
})
function StartDetection {
 if($script:worker){return}
 try{
  foreach($k in @('asset','hython')){if(-not(Test-Path -LiteralPath $script:fields[$k].Text -PathType Leaf)){throw ('请先选择有效文件：'+$k)}}
  $info=New-Object Diagnostics.ProcessStartInfo;$info.FileName=$script:fields['hython'].Text
  $info.Arguments='"'+(Join-Path $PSScriptRoot 'restore.py')+'" --detect "'+$script:fields['asset'].Text+'"'
  $info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  $info.StandardOutputEncoding=[Text.Encoding]::UTF8;$info.StandardErrorEncoding=[Text.Encoding]::UTF8;$info.EnvironmentVariables['PYTHONIOENCODING']='utf-8'
  $script:worker=New-Object Diagnostics.Process;$script:worker.StartInfo=$info;$script:detecting=$true;$log.Clear()
  $null=$script:worker.Start();$script:lineTask=$script:worker.StandardOutput.ReadLineAsync();$script:errTask=$script:worker.StandardError.ReadToEndAsync()
  $start.Enabled=$false;$detect.Enabled=$false;$status.Text='读取 uasset 包头并匹配本机引擎…';$timer.Start()
 }catch{$script:worker=$null;$script:detecting=$false;LogLine $_.Exception.Message}
}
$detect.Add_Click({StartDetection})
$startHandler={
 try{
  if($script:worker){throw '上一项任务尚未完成。'}
  foreach($k in @('asset','hython')){if(-not(Test-Path -LiteralPath $script:fields[$k].Text -PathType Leaf)){throw ('请选择有效文件：'+$k)}}
  if($script:fields['engine'].Text.Trim() -and -not(Test-Path -LiteralPath $script:fields['engine'].Text -PathType Leaf)){throw '手动指定的 UE 程序不存在。'}
  if(-not $script:fields['output'].Text.Trim()){throw '请选择输出父目录。'}
  $cfg=@{};foreach($k in $script:fields.Keys){$cfg[$k]=$script:fields[$k].Text}
  $script:request=Join-Path ([IO.Path]::GetTempPath()) ('ABCRestore_'+[guid]::NewGuid().ToString('N')+'.json')
  [IO.File]::WriteAllText($script:request,($cfg|ConvertTo-Json),[Text.UTF8Encoding]::new($false))
  $info=New-Object Diagnostics.ProcessStartInfo;$info.FileName=$cfg.hython;$script:usedHython=$cfg.hython
  $info.Arguments='"'+(Join-Path $PSScriptRoot 'restore.py')+'" --config "'+$script:request+'"'
  $info.UseShellExecute=$false;$info.CreateNoWindow=$true;$info.RedirectStandardOutput=$true;$info.RedirectStandardError=$true
  $info.StandardOutputEncoding=[Text.Encoding]::UTF8;$info.StandardErrorEncoding=[Text.Encoding]::UTF8;$info.EnvironmentVariables['PYTHONIOENCODING']='utf-8'
  $script:worker=New-Object Diagnostics.Process;$script:worker.StartInfo=$info
  $script:success=$false;$script:result=$null;$script:detecting=$false;$log.Clear();$bar.Value=0
  $openHip.Enabled=$false;$openABC.Enabled=$false;$openDir.Enabled=$false
  $null=$script:worker.Start();$script:lineTask=$script:worker.StandardOutput.ReadLineAsync();$script:errTask=$script:worker.StandardError.ReadToEndAsync()
  $start.Enabled=$false;$detect.Enabled=$false;foreach($b in $script:fields.Values){$b.ReadOnly=$true}
  $status.Text='正在启动后台还原任务…';$timer.Start()
 }catch{
  LogLine $_.Exception.Message;$status.Text='无法开始还原，请检查输入。'
  if($script:worker){$script:worker.Dispose();$script:worker=$null}
  $start.Enabled=$true
 }
}
$start.Add_Click($startHandler)
$openHip.Add_Click({Start-Process -FilePath (Join-Path (Split-Path $script:usedHython -Parent) 'houdini.exe') -ArgumentList ('"'+$script:result.hip+'"')})
$openABC.Add_Click({Start-Process explorer.exe -ArgumentList ('/select,"'+$script:result.abc+'"')})
$openDir.Add_Click({Start-Process explorer.exe -ArgumentList ('"'+$script:result.directory+'"')})
$form.Add_FormClosing({
 if($script:worker -and -not $script:worker.HasExited){
  $_.Cancel=$true;[Windows.Forms.MessageBox]::Show('还原仍在进行，请等待任务完成后关闭。','任务进行中')|Out-Null
 }
})
if($IntegrationConfig){
 $cfg=Get-Content -LiteralPath $IntegrationConfig -Raw -Encoding UTF8|ConvertFrom-Json
 foreach($k in $script:fields.Keys){$script:fields[$k].Text=$cfg.$k}
 & $startHandler
 $deadline=[DateTime]::UtcNow.AddMinutes(20)
 while($script:worker -and [DateTime]::UtcNow -lt $deadline){[Windows.Forms.Application]::DoEvents();Start-Sleep -Milliseconds 50}
 if($script:worker){throw 'Integration timeout; worker may still be running'}
 if(-not $script:success -or -not $openHip.Enabled -or -not $openABC.Enabled){throw ('Integration failed: '+$log.Text)}
 Write-Output ('INTEGRATION_OK: '+$script:result.hip);$form.Dispose()
}elseif($SmokeTest){
 if($script:fields.Count -ne 4){throw 'UI setup failed'}
 Write-Output 'UI_OK: ABC Restore standalone';$form.Dispose()
}else{[Windows.Forms.Application]::Run($form)}
