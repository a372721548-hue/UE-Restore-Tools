"""Convert the extractor's synchronized Geometry Cache samples with Houdini."""
import json
from fractions import Fraction
from pathlib import Path


def convert(raw, out, emit):
    import hou
    import numpy as np
    raw, out = Path(raw), Path(out)
    manifest = json.loads((raw / 'manifest.json').read_text(encoding='utf-8-sig'))
    tracks = manifest['tracks']
    if not tracks or not tracks[0]['samples']:
        raise ValueError('资产没有可读取的网格采样。')
    times = np.asarray([s['time'] for s in tracks[0]['samples']])
    count = len(times)
    for track in tracks:
        tt = [s['time'] for s in track['samples']]
        if len(tt) != count or not np.allclose(times, tt, atol=1e-6, rtol=0):
            raise ValueError('此缓存的轨道采样时间不一致，当前版本不支持自动重采样。')
    if count < 2:
        fps = 24.0
    else:
        dt = float(np.median(np.diff(times)))
        if dt <= 0 or not np.allclose(np.diff(times), dt, atol=2e-6, rtol=0):
            raise ValueError('当前版本需要等间隔网格采样；检测到非均匀时间序列。')
        rate = 1 / dt
        common = [24,25,30,48,50,60,120,24000/1001,30000/1001,60000/1001]
        nearest = min(common, key=lambda x: abs(x-rate))
        fps = nearest if abs(nearest-rate)/rate < 1e-5 else float(Fraction(rate).limit_denominator(1001))
    first = int(manifest['start_frame']); last = first + count - 1
    if last != manifest['end_frame']:
        raise ValueError('资产帧范围与采样数不一致，当前版本不自动猜测缺失帧。')
    emit('status', message=f'识别 {len(tracks)} 条轨道，{first}–{last} 帧，{fps:g} FPS。')
    (out / 'cache').mkdir()
    (out / 'INCOMPLETE.txt').write_text('任务尚未完成，工程和 ABC 未经最终验证。', encoding='utf-8')
    stats = []
    for index, time in enumerate(times):
        frame = first + index
        combined = hou.Geometry()
        for ti, track in enumerate(tracks):
            s = track['samples'][index]
            if not s['visible']:
                continue
            prefix = raw / s['prefix']
            p = np.fromfile(str(prefix)+'.P', dtype='<f4').reshape(-1,3)
            indices = np.fromfile(str(prefix)+'.I', dtype='<u4').reshape(-1,3)
            if len(p) != s['vertices'] or indices.size != s['indices'] or (indices.size and indices.max() >= len(p)):
                raise ValueError(f'第 {frame} 帧的索引或顶点数量异常。')
            matrix = np.asarray(s['matrix']).reshape(4,4)
            p = (np.column_stack([p,np.ones(len(p))]) @ matrix)[:,:3]
            p = (p[:,[0,2,1]] * .01).astype(np.float32)
            if not np.isfinite(p).all():
                raise ValueError(f'第 {frame} 帧包含无效坐标。')
            # Reflect axes and account for the track transform's handedness.
            if np.linalg.det(matrix[:3,:3]) >= 0:
                indices = indices[:,[0,2,1]]
            geo = hou.Geometry(); points = geo.createPoints(p.tolist())
            for tri in indices:
                poly = geo.createPolygon()
                for point in tri:
                    poly.addVertex(points[int(point)])
            if s.get('uv'):
                uv = np.fromfile(str(prefix)+'.UV',dtype='<f4').reshape(-1,2)
                uv[:,1] = 1-uv[:,1]; uv = np.column_stack([uv,np.zeros(len(uv))])
                geo.addAttrib(hou.attribType.Point,'uv',(0.,0.,0.))
                geo.setPointFloatAttribValues('uv',uv.reshape(-1).tolist())
            if s.get('normals'):
                n = np.fromfile(str(prefix)+'.N',dtype='<f4').reshape(-1,3) @ np.linalg.inv(matrix[:3,:3]).T
                n = n[:,[0,2,1]]; n /= np.maximum(np.linalg.norm(n,axis=1)[:,None],1e-12)
                geo.addAttrib(hou.attribType.Point,'N',(0.,0.,0.))
                geo.setPointFloatAttribValues('N',n.reshape(-1).tolist())
            if s.get('colors'):
                bgra = np.fromfile(str(prefix)+'.C',dtype=np.uint8).reshape(-1,4)/255.
                geo.addAttrib(hou.attribType.Point,'Cd',(1.,1.,1.)); geo.setPointFloatAttribValues('Cd',bgra[:,[2,1,0]].reshape(-1).tolist())
                geo.addAttrib(hou.attribType.Point,'Alpha',1.); geo.setPointFloatAttribValues('Alpha',bgra[:,3].tolist())
            geo.addAttrib(hou.attribType.Prim,'name',f'track_{ti:02d}')
            geo.addAttrib(hou.attribType.Prim,'material_id',0)
            mats = np.zeros(len(indices),dtype=int)
            for batch in s['batches']:
                start = batch['start']//3; mats[start:start+batch['triangles']] = batch['material']
            geo.setPrimIntAttribValues('material_id',mats.tolist())
            combined.merge(geo)
        combined.addAttrib(hou.attribType.Global,'source_time',float(time))
        combined.addAttrib(hou.attribType.Global,'source_asset',manifest['asset'])
        combined.saveToFile(str(out/'cache'/f'geometry.{frame:04d}.bgeo.sc'))
        stats.append(dict(frame=frame,time=float(time),vertices=len(combined.points()),triangles=len(combined.prims())))
        emit('progress',value=25+int((index+1)/count*35),message=f'生成网格 {index+1}/{count} 帧')
    hou.hipFile.clear(suppress_save_prompt=True)
    obj = hou.node('/obj').createNode('geo','GeometryCache_Restored')
    f = obj.createNode('file','READ_CACHE'); f.parm('file').set('$HIP/cache/geometry.$F4.bgeo.sc')
    end = obj.createNode('null','OUT_ANIMATION'); end.setInput(0,f); end.setDisplayFlag(True); end.setRenderFlag(True)
    obj.layoutChildren()
    note = obj.createStickyNote('README')
    note.setText(f'Geometry Cache restored | Frames {first}-{last} | {fps:g} FPS\nY up, metres. Dynamic topology preserved.\nKeep cache folder next to this HIP. Restored.abc is standalone.\nUE materials and level actor transforms are not included.')
    note.setSize(hou.Vector2(8,3))
    hou.setFps(fps); hou.playbar.setFrameRange(first,last); hou.playbar.setPlaybackRange(first,last); hou.setFrame(first)
    hou.hipFile.save(str(out/'Restored.hip')); hip = hou.hipFile.path()
    hou.hipFile.load(hip,suppress_save_prompt=True)
    obj = hou.node('/obj/GeometryCache_Restored'); end = obj.node('OUT_ANIMATION')
    emit('status',message='导出 ABC；较大的缓存可能需要稍等…')
    rop = hou.node('/out').createNode('alembic','EXPORT_ABC')
    rop.parm('filename').set('$HIP/Restored.abc'); rop.parm('use_sop_path').set(1); rop.parm('sop_path').set(end.path())
    rop.parm('trange').set(1); rop.parmTuple('f').set((first,last,1)); rop.render(frame_range=(first,last))
    if not (out/'Restored.abc').is_file():
        raise RuntimeError('未生成 ABC；请检查 Houdini 许可证是否允许 Alembic 导出。')
    check = obj.createNode('alembic','VERIFY_ABC'); check.parm('fileName').set('$HIP/Restored.abc')
    check.parm('loadmode').set('unpack'); check.parm('fps').set(fps)
    max_error = 0.
    for index,frame in enumerate(range(first,last+1)):
        hou.setFrame(frame)
        original = hou.Geometry(); original.loadFromFile(str(out/'cache'/f'geometry.{frame:04d}.bgeo.sc'))
        expected = np.asarray(original.pointFloatAttribValues('P')).reshape(-1,3)
        hipgeo = end.geometry(); abcgeo = check.geometry()
        if len(hipgeo.prims()) != stats[index]['triangles'] or not np.array_equal(hipgeo.pointFloatAttribValues('P'),original.pointFloatAttribValues('P')):
            raise RuntimeError(f'Houdini 工程第 {frame} 帧重新加载验证失败。')
        p = np.asarray(abcgeo.pointFloatAttribValues('P')).reshape(-1,3)
        if len(abcgeo.prims()) != stats[index]['triangles'] or p.shape != expected.shape:
            raise RuntimeError(f'ABC 第 {frame} 帧顶点数或面数校验失败。')
        error = float(np.max(np.abs(p-expected))) if p.size else 0
        if error > 1e-5:
            raise RuntimeError(f'ABC 第 {frame} 帧位置误差超过允许范围。')
        max_error = max(max_error,error)
        emit('progress',value=65+int((index+1)/count*34),message=f'验证工程与 ABC {index+1}/{count} 帧')
    check.destroy(); hou.setFrame(first); hou.hipFile.save()
    report = dict(source=manifest['asset'],frames=count,first_frame=first,last_frame=last,fps=fps,
                  tracks=len(tracks),source_duration=manifest['duration'],source_times=times.tolist(),stats=stats,
                  abc_max_position_error_metres=max_error,validation='All HIP and ABC samples decoded and checked.',hip=hip)
    (out/'validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    (out/'使用说明.txt').write_text(f'打开 {Path(hip).name}，播放 {first}–{last} 帧，{fps:g} FPS。\nRestored.abc 可以单独导入其他 DCC。\nHoudini 工程需与 cache 文件夹放在一起。\nY 向上，米为单位。保留可用法线、UV、颜色与材质编号，不重建 UE 材质。\n恢复 UE 资产局部动画，不包含关卡 Actor 变换。\n_extraction 保存诊断日志与原始解码数据，播放不依赖它。\n',encoding='utf-8')
    (out/'INCOMPLETE.txt').unlink()
    return dict(hip=hip,abc=str(out/'Restored.abc'),directory=str(out),frames=count,fps=fps)
