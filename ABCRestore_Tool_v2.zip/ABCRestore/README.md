# ABC Restore v2 — 独立 Geometry Cache 还原工具

这不是 VAT 工具；本文件夹无需 VAT 工具的任何文件。输入 UE 的 **Geometry Cache `.uasset`**，输出可播放的 **ABC、Houdini 工程和 `.bgeo.sc` 缓存**。

## 使用

解压整个文件夹，双击 **Launch.vbs**。

1. 选择几何缓存 `.uasset`（不是 T3D/COPY，也不是普通静态网格）。
2. UE 路径留空使用自动选择；也可手动指定 `Engine/Binaries/Win64/UnrealEditor-Cmd.exe`。选择资产后会识别版本，也可点击“识别版本”。
3. 选择 Houdini 安装目录中的 `bin/hython.exe`。
4. 选择输出父目录，点击“开始还原”。帧率及帧数从缓存采样时间识别。
5. 完成后可以打开 Houdini 工程或定位 ABC 文件。

无需提前打开 UE 或 Houdini，也不需要原始 ABC。每次生成独立结果文件夹，不覆盖之前的结果。源资产被复制到独立提取工程，没有调用保存源工程的操作。存在同名 `.uexp`、`.ubulk`、`.uptnl` 时一起复制。

## 自动识别与跨版本适配

- 从 `.uasset` 包头读取最后保存的引擎版本及兼容版本，同时读取所属 `.uproject` 的 EngineAssociation。它们不一定相同；包头也不能说明资产最初是在哪个版本制作的。
- 自动选择同一主/次版本中可用的较新补丁版本；若所属工程版本更新，优先按工程版本选择。例如 bloodXiru 记录保存版本 5.3.2，但所属工程是 5.6，本机自动选择 5.6.1。
- 搜索注册表、Epic Launcher 安装记录和常见安装目录；找不到匹配项时请手动定位引擎。不会自动下载引擎，也不会随机改用最高版本。
- 缺失版本信息或未知包头结构时，明确显示无法识别，依靠工程版本或手动选择。当前包头解析覆盖 UE5 格式编号 1000–1018；不保证未来包头仍可解析。
- 手动选择更新引擎时只处理资产副本；拒绝比资产保存版本更旧的引擎。更新引擎能否实际解码，以运行结果为准。
- 按引擎 BuildId 匹配提取模块。附带匹配模块可直接用；其他版本首次使用会从 `Extractor/Source` 自动编译，并保存在工具目录 `ModuleCache`。后续相同引擎构建与源码复用缓存。
- 首次编译需要所选 UE 的完整构建工具、受该 UE 支持的 Visual Studio C++ 工具链和 Windows SDK。工具目录需可写。引擎更新或提取源码变化可能触发重新编译；接口变化仍可能需要更新工具，不能承诺所有未来版本自动兼容。

## 运行条件与范围

- Windows。已完整实测 **UE 5.6.1 自动选择**与 **UE 5.8.3 自动编译及提取**；其他引擎版本尚未逐一验证。附带模块 BuildId 为 43139311，不会修改模块版本号绕过兼容检查。
- 已安装并授权的 Houdini，需有 Alembic 导出能力。已用 Houdini 21.0.440 验证。不需要另装 Python；使用未附带的引擎模块时需要上述编译环境。
- 使用编辑器里的未烹饪 Geometry Cache 资产。不能从打包后的游戏资源直接提取。
- 支持 UE 的 Streamable Geometry Cache 轨道、动态拓扑及单轨道/同步多轨道的均匀网格采样。非同步轨道、非均匀采样、帧范围不一致、其他轨道类型会明确报错。
- 导出各网格采样时刻的轨道变换与可见性；不额外采样网格帧之间独立的变换/可见性关键帧。
- 保留可用位置、法线、UV、颜色和材质编号。Houdini 单位为米、Y 向上。UE 材质、关卡 Actor 变换、导入压缩前的数据不在恢复范围。
- 还原大型资产期间请等待任务结束再关闭窗口。没有提供中途取消按钮。

## 结果文件

- `Restored.abc`：可单独导入 Houdini 或其他支持 Alembic 的 DCC。
- `Restored.hip`（扩展名可能随许可证变化）：需要旁边的 `cache` 文件夹。
- `validation.json`：帧率、帧范围、逐帧统计及 ABC 位置误差。
- `_extraction`：独立提取工程、UE 日志和原始解码数据。播放不依赖该目录。
- `_extraction/engine_detection.json`：资产保存版本、所属工程版本与实际使用引擎的识别记录。
- `INCOMPLETE.txt`：若仍存在，说明这次任务没有通过全部验证。

工具生成工程后，会重新读取每帧 Houdini 缓存和 ABC，检查顶点数、三角面数及顶点位置。失败不会显示成功。

## 故障处理

- **无法匹配引擎**：安装所需版本，或手动选择合适的 `UnrealEditor-Cmd.exe`。
- **模块编译失败**：查看界面指出的 `ModuleCache/.../build.log`，检查 Visual Studio C++、Windows SDK 与 UE 构建工具是否齐全。新版本 UE 的接口变化可能需要修改提取源码。
- **UE 解码失败**：确认输入是 Geometry Cache，配套二进制文件齐全，并查看输出目录 `_extraction/unreal.log`。
- **ABC 导出失败**：确认 Houdini 授权允许 Alembic 输出；先保留日志和已有缓存。
- **系统禁用 VBS**：用 Windows PowerShell 执行 `powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "工具目录\ABCRestore.ps1"`。

本工具保留源码，UE 提取模块来自本次 Geometry Cache 提取流程，不依赖原 RPG 工程或 VAT 工具。

v2 验证：bloodXiru 的两次跨引擎还原均为 31 帧、24 FPS；每帧位置、三角形连接及可用点属性与原已验证结果一致，ABC 读回位置误差为 0。另验证了真实 UE 5.3/5.8 包头、缺失版本、损坏包头、旧引擎拒绝、缺少安装引擎及编译缓存复用。
